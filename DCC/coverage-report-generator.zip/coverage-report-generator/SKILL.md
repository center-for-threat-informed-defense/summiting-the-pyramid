---
name: coverage-report-generator
description: Generate executive-ready ATT&CK coverage reports from a standardized Excel workbook with Summary, Technique Coverage, and Analytic Scores sheets. Use when asked to analyze that workbook format and produce a PDF report, optionally ATT&CK Navigator layers, for cyber leadership.
---

# Coverage Report Generator

Use this skill for the standardized ATT&CK coverage workbook format only. Require these sheets: `Summary`, `Technique Coverage`, and `Analytic Scores`. If any are missing or the column layout is unexpected, stop and report the problem rather than guessing.

## Workflow

1. Validate the workbook schema.
2. Parse summary metrics, technique coverage rows, and analytic scores.
3. Ask whether ATT&CK Navigator layers should also be generated; default to PDF only.
4. Generate an executive PDF report with this order:
   - Cover page
   - Executive assessment banner
   - Executive summary
   - Dashboard-style Analysis-at-a-Glance
   - Score and coverage distributions (all three histograms on one page)
   - Technique coverage table
   - Analytic scores table
   - Key observations
   - Decision-maker takeaways
   - Appendix (Navigator layers only when requested)

## Calculation rules

- Overall coverage = `sum(Matched Implementation Count) / sum(Total Implementation Count)` from the `Technique Coverage` sheet.
- Techniques with coverage = integer count of techniques with at least one matched implementation.
- Implementation matches = `matched/total` shown as `X/Y`.
- Technique-level average robustness and precision = averages of the analytic files listed for each technique, using numeric values from `Analytic Scores`.
- Show robustness, precision, and coverage values as numbers only in tables; use color coding without explanatory text.
- Use these thresholds:
  - Coverage: green `>= 75%`, yellow `40-74%`, red `< 40%`
  - Robustness and precision: green `>= 2.5`, yellow `1.6-2.4`, red `<= 1.5`

## Output rules

- Use the technique names already present in the workbook; do not invent external ATT&CK lookups.
- Keep the dashboard as a single visual summary on the first summary page.
- Keep all three histograms on the same page.
- Preserve the standardized workbook format and report layout across runs.
