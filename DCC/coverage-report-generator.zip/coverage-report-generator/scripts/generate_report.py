#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import re
import statistics
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from openpyxl import load_workbook
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape, portrait
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    LongTable,
    Paragraph,
    PageBreak,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

COVERAGE_GREEN = colors.HexColor("#2E7D32")
COVERAGE_YELLOW = colors.HexColor("#F9A825")
COVERAGE_RED = colors.HexColor("#C62828")
PALETTE = ["#2E7D32", "#F9A825", "#C62828", "#1565C0", "#6A1B9A", "#00838F"]


@dataclass
class TechniqueRow:
    technique_id: str
    technique_name: str
    matched_count: int
    total_count: int
    coverage_ratio: str
    coverage_percent: float
    analytic_files: List[str]
    analytic_titles: List[str]

    @property
    def has_coverage(self) -> bool:
        return self.matched_count > 0


@dataclass
class AnalyticScore:
    file: str
    title: str
    robustness: Optional[float]
    precision: Optional[float]
    expression: str
    missing_scores: str
    notes: str

    @property
    def scored(self) -> bool:
        return self.robustness is not None and self.precision is not None


@dataclass
class SummaryData:
    analytics_processed: int
    analytic_files: List[str]
    technique_ids: List[str]
    covered_implementation_row_count: int
    technique_coverage_row_count: int
    analytic_score_row_count: int
    raw: Dict[str, Any]


def parse_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    s = str(value).strip()
    if not s:
        return default
    s = s.replace(",", "")
    try:
        return int(float(s))
    except ValueError:
        return default


def parse_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        if math.isnan(value):
            return None
        return float(value)
    s = str(value).strip()
    if not s:
        return None
    s = s.replace("%", "")
    try:
        return float(s)
    except ValueError:
        return None


def split_list(value: Any, delimiter: str = ";") -> List[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        items = [str(x).strip() for x in value]
    else:
        items = [x.strip() for x in str(value).split(delimiter)]
    return [x for x in items if x]


def safe_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def metric_to_float(label: str, value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    s = str(value).strip()
    if not s:
        return None
    # allow "0.0%" and "63/764"; percent is used for coverage only
    if label.lower().endswith("percent") or label.lower().endswith("coverage"):
        s = s.replace("%", "")
    try:
        return float(s)
    except ValueError:
        return None


def load_summary(ws) -> SummaryData:
    data: Dict[str, Any] = {}
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or row[0] is None:
            continue
        key = str(row[0]).strip()
        data[key] = row[1]
    analytic_files = split_list(data.get("Analytic Files"), ";")
    technique_ids = split_list(data.get("ATT&CK Technique IDs"), ",")
    return SummaryData(
        analytics_processed=parse_int(data.get("Analytics Processed"), len(analytic_files)),
        analytic_files=analytic_files,
        technique_ids=technique_ids,
        covered_implementation_row_count=parse_int(data.get("Covered Implementation Row Count"), 0),
        technique_coverage_row_count=parse_int(data.get("Technique Coverage Row Count"), 0),
        analytic_score_row_count=parse_int(data.get("Analytic Score Row Count"), 0),
        raw=data,
    )


def load_technique_coverage(ws) -> List[TechniqueRow]:
    rows: List[TechniqueRow] = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        percent = parse_float(row[5])
        if percent is None:
            # Allow ratio-derived numeric fallback if a percent cell is empty.
            percent = 0.0
        rows.append(
            TechniqueRow(
                technique_id=safe_text(row[0]),
                technique_name=safe_text(row[1]),
                matched_count=parse_int(row[2]),
                total_count=parse_int(row[3]),
                coverage_ratio=safe_text(row[4]),
                coverage_percent=percent,
                analytic_files=split_list(row[8], ";"),
                analytic_titles=split_list(row[9], ";"),
            )
        )
    return rows


def load_analytic_scores(ws) -> List[AnalyticScore]:
    rows: List[AnalyticScore] = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        rows.append(
            AnalyticScore(
                file=safe_text(row[0]),
                title=safe_text(row[1]),
                robustness=parse_float(row[3]),
                precision=parse_float(row[4]),
                expression=safe_text(row[5]),
                missing_scores=safe_text(row[6]),
                notes=safe_text(row[7]),
            )
        )
    return rows


def build_score_lookup(scores: Sequence[AnalyticScore]) -> Dict[str, AnalyticScore]:
    return {s.file: s for s in scores}


def overall_coverage(techniques: Sequence[TechniqueRow]) -> Tuple[int, int, float]:
    matched = sum(t.matched_count for t in techniques)
    total = sum(t.total_count for t in techniques)
    pct = (matched / total * 100.0) if total else 0.0
    return matched, total, pct


def avg_or_none(values: Sequence[float]) -> Optional[float]:
    vals = [v for v in values if v is not None]
    if not vals:
        return None
    return sum(vals) / len(vals)


def technique_averages(technique: TechniqueRow, score_lookup: Dict[str, AnalyticScore]) -> Tuple[Optional[float], Optional[float]]:
    robustness_vals: List[float] = []
    precision_vals: List[float] = []
    for file in technique.analytic_files:
        score = score_lookup.get(file)
        if not score:
            continue
        if score.robustness is not None:
            robustness_vals.append(score.robustness)
        if score.precision is not None:
            precision_vals.append(score.precision)
    return avg_or_none(robustness_vals), avg_or_none(precision_vals)


def bucket_color(value: Optional[float], metric: str) -> colors.Color:
    if value is None:
        return colors.HexColor("#E0E0E0")
    if metric == "coverage":
        if value >= 75:
            return COVERAGE_GREEN
        if value >= 40:
            return COVERAGE_YELLOW
        return COVERAGE_RED
    if value >= 2.5:
        return COVERAGE_GREEN
    if value >= 1.6:
        return COVERAGE_YELLOW
    return COVERAGE_RED


def rating_text(value: float, metric: str) -> str:
    if metric == "coverage":
        if value >= 75:
            return "Good"
        if value >= 40:
            return "Moderate"
        return "Needs Improvement"
    if value >= 2.5:
        return "Good"
    if value >= 1.6:
        return "Moderate"
    return "Needs Improvement"


def make_dashboard_png(output: Path, summary: SummaryData, techniques: Sequence[TechniqueRow], scores: Sequence[AnalyticScore]) -> Path:
    matched, total, coverage_pct = overall_coverage(techniques)
    scored = [s for s in scores if s.scored]
    avg_robustness = avg_or_none([s.robustness for s in scored if s.robustness is not None]) or 0.0
    avg_precision = avg_or_none([s.precision for s in scored if s.precision is not None]) or 0.0
    techniques_with_coverage = sum(1 for t in techniques if t.has_coverage)
    unscored = len(scores) - len(scored)

    fig = plt.figure(figsize=(14, 8), dpi=180)
    fig.patch.set_facecolor("white")
    gs = fig.add_gridspec(4, 3, height_ratios=[0.7, 1.0, 1.0, 1.0], hspace=0.38, wspace=0.2)

    ax_banner = fig.add_subplot(gs[0, :])
    ax_banner.axis("off")
    banner_cards = [
        (0.01, 0.12, 0.31, 0.52, "Overall Coverage", f"{coverage_pct:.1f}%", rating_text(coverage_pct, "coverage")),
        (0.345, 0.12, 0.31, 0.52, "Overall Robustness", f"{avg_robustness:.2f}", rating_text(avg_robustness, "quality")),
        (0.68, 0.12, 0.31, 0.52, "Overall Precision", f"{avg_precision:.2f}", rating_text(avg_precision, "quality")),
    ]
    for x, y, w, h, title, value, rating in banner_cards:
        rect = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.02", linewidth=1.2, edgecolor="#BDBDBD", facecolor="#F8F9FA")
        ax_banner.add_patch(rect)
        ax_banner.text(x + 0.03, y + h - 0.12, title, fontsize=11, fontweight="bold", va="top")
        ax_banner.text(x + 0.03, y + 0.16, value, fontsize=20, fontweight="bold", va="bottom", color="#1F1F1F")
        ax_banner.text(x + w - 0.03, y + 0.16, rating, fontsize=10, ha="right", va="bottom", color="#4F4F4F")

    metrics = [
        ("Analytics Evaluated", str(summary.analytics_processed)),
        ("Technique IDs Covered", str(len(summary.technique_ids) or len(techniques))),
        ("Techniques with Coverage", str(techniques_with_coverage)),
        ("Implementation Matches", f"{matched}/{total}"),
        ("Scored Analytics", str(len(scored))),
        ("Unscored Analytics", str(unscored)),
        ("Avg Robustness", f"{avg_robustness:.2f}"),
        ("Avg Precision", f"{avg_precision:.2f}"),
        ("ATT&CK Version", "v19.1"),
    ]
    for i, (label, value) in enumerate(metrics):
        r = 1 + i // 3
        c = i % 3
        ax = fig.add_subplot(gs[r, c])
        ax.axis("off")
        card = FancyBboxPatch((0.02, 0.08), 0.96, 0.84, boxstyle="round,pad=0.03,rounding_size=0.03", linewidth=1.1, edgecolor="#D0D0D0", facecolor="#FCFCFC")
        ax.add_patch(card)
        ax.text(0.08, 0.74, label, fontsize=10.5, fontweight="bold", va="top")
        ax.text(0.08, 0.26, value, fontsize=18, fontweight="bold", va="bottom")

    fig.tight_layout(rect=[0, 0, 1, 0.98])
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output


def coverage_hist_counts(values: Sequence[float]) -> Tuple[List[str], List[int]]:
    bins = [
        (0.0, 0.0001, "0%"),
        (0.0001, 25.0, "1-25%"),
        (25.0, 50.0, "26-50%"),
        (50.0, 75.0, "51-75%"),
        (75.0, 99.9999, "76-99%"),
        (99.9999, 100.0001, "100%"),
    ]
    labels: List[str] = []
    counts: List[int] = []
    for lo, hi, label in bins:
        labels.append(label)
        if label == "0%":
            count = sum(1 for v in values if v == 0)
        elif label == "100%":
            count = sum(1 for v in values if v >= 100.0)
        else:
            count = sum(1 for v in values if (v > lo) and (v <= hi))
        counts.append(count)
    return labels, counts


def make_histogram_png(output: Path, techniques: Sequence[TechniqueRow], scores: Sequence[AnalyticScore]) -> Path:
    robustness = [s.robustness for s in scores if s.robustness is not None]
    precision = [s.precision for s in scores if s.precision is not None]
    coverage = [t.coverage_percent for t in techniques]

    fig, axes = plt.subplots(1, 3, figsize=(16, 5), dpi=180)
    fig.patch.set_facecolor("white")
    histogram_specs = [
        (axes[0], robustness, [0.5, 1.5, 2.5, 3.5, 4.5], ["1", "2", "3", "4"], "Robustness Distribution", "Robustness Score", "Analytics"),
        (axes[1], precision, [0.5, 1.5, 2.5, 3.5, 4.5], ["1", "2", "3", "4"], "Precision Distribution", "Precision Score", "Analytics"),
    ]
    for ax, vals, bins, labels, title, xlabel, ylabel in histogram_specs:
        counts, edges = np_hist(vals, bins)
        ax.bar(labels, counts, color=PALETTE[:len(labels)])
        ax.set_title(title, fontsize=13, fontweight="bold")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", alpha=0.2)

    cov_labels, cov_counts = coverage_hist_counts(coverage)
    ax = axes[2]
    colors_for_bins = ["#C62828", "#C62828", "#F9A825", "#F9A825", "#2E7D32", "#2E7D32"]
    ax.bar(cov_labels, cov_counts, color=colors_for_bins)
    ax.set_title("Implementation Coverage Distribution", fontsize=13, fontweight="bold")
    ax.set_xlabel("Coverage Bucket")
    ax.set_ylabel("Techniques")
    ax.grid(axis="y", alpha=0.2)
    ax.tick_params(axis='x', rotation=30)

    fig.suptitle("Score and Coverage Distributions", fontsize=18, fontweight="bold", y=1.03)
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output


def np_hist(vals: Sequence[float], bins: Sequence[float]) -> Tuple[List[int], List[float]]:
    import numpy as np
    counts, edges = np.histogram(vals, bins=bins)
    return counts.tolist(), edges.tolist()


def make_bar_for_rating(value: Optional[float], metric: str) -> colors.Color:
    return bucket_color(value, metric)


def p(text: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(text, style)


def build_pdf(
    workbook_path: Path,
    output_pdf: Path,
    include_navigator: bool = False,
    navigator_dir: Optional[Path] = None,
) -> Path:
    wb = load_workbook(workbook_path, data_only=True)
    required = ["Summary", "Technique Coverage", "Analytic Scores"]
    missing = [s for s in required if s not in wb.sheetnames]
    if missing:
        raise ValueError(f"Missing required sheets: {', '.join(missing)}")

    summary = load_summary(wb["Summary"])
    techniques = load_technique_coverage(wb["Technique Coverage"])
    scores = load_analytic_scores(wb["Analytic Scores"])
    score_lookup = build_score_lookup(scores)

    # Compute technique averages in workbook order.
    technique_avgs: Dict[str, Tuple[Optional[float], Optional[float]]] = {}
    for technique in techniques:
        technique_avgs[technique.technique_id] = technique_averages(technique, score_lookup)

    matched, total, coverage_pct = overall_coverage(techniques)
    scored_scores = [s for s in scores if s.scored]
    avg_robustness = avg_or_none([s.robustness for s in scored_scores if s.robustness is not None]) or 0.0
    avg_precision = avg_or_none([s.precision for s in scored_scores if s.precision is not None]) or 0.0
    techniques_with_coverage = sum(1 for t in techniques if t.has_coverage)
    unscored_scores = [s for s in scores if not s.scored]

    # Charts
    out_dir = output_pdf.parent / f"{output_pdf.stem}_assets"
    out_dir.mkdir(parents=True, exist_ok=True)
    dashboard_png = make_dashboard_png(out_dir / "summary_dashboard.png", summary, techniques, scores)
    dist_png = make_histogram_png(out_dir / "score_and_coverage_distributions.png", techniques, scores)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleCustom", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=24, leading=28, alignment=TA_CENTER, spaceAfter=14)
    h1 = ParagraphStyle("H1", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=16, leading=20, spaceBefore=10, spaceAfter=8)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=12, leading=15, spaceBefore=8, spaceAfter=6)
    body = ParagraphStyle("Body", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.5, leading=12, spaceAfter=4)
    body_small = ParagraphStyle("BodySmall", parent=body, fontSize=8.5, leading=10.5)
    table_text = ParagraphStyle("TableText", parent=body_small, alignment=TA_LEFT)
    center_small = ParagraphStyle("CenterSmall", parent=body_small, alignment=TA_CENTER)

    story: List[Any] = []
    workbook_name = workbook_path.name
    story.append(Spacer(1, 0.7 * inch))
    story.append(p("ATT&amp;CK Coverage Executive Report", title_style))
    story.append(p(f"{workbook_name}", ParagraphStyle("Sub", parent=body, alignment=TA_CENTER, fontSize=12, leading=15)))
    story.append(Spacer(1, 0.2 * inch))
    story.append(p(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')} | ATT&amp;CK v19.1", ParagraphStyle("Sub2", parent=body, alignment=TA_CENTER, fontSize=10, textColor=colors.grey)))
    story.append(PageBreak())

    # Executive assessment and narrative
    rating_table = Table(
        [[
            p("Overall Coverage", h2),
            p("Overall Robustness", h2),
            p("Overall Precision", h2),
        ], [
            p(f"<font color='#FFFFFF'><b>{coverage_pct:.1f}%</b></font>", ParagraphStyle("k1", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=18, alignment=TA_CENTER)),
            p(f"<font color='#FFFFFF'><b>{avg_robustness:.2f}</b></font>", ParagraphStyle("k2", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=18, alignment=TA_CENTER)),
            p(f"<font color='#FFFFFF'><b>{avg_precision:.2f}</b></font>", ParagraphStyle("k3", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=18, alignment=TA_CENTER)),
        ], [
            p(rating_text(coverage_pct, "coverage"), center_small),
            p(rating_text(avg_robustness, "quality"), center_small),
            p(rating_text(avg_precision, "quality"), center_small),
        ]
    ], colWidths=[2.35*inch, 2.35*inch, 2.35*inch])
    rating_table.setStyle(TableStyle([
        ("GRID", (0,0), (-1,-1), 0.8, colors.white),
        ("BACKGROUND", (0,0), (0,-1), make_bar_for_rating(coverage_pct, "coverage")),
        ("BACKGROUND", (1,0), (1,-1), make_bar_for_rating(avg_robustness, "quality")),
        ("BACKGROUND", (2,0), (2,-1), make_bar_for_rating(avg_precision, "quality")),
        ("TEXTCOLOR", (0,0), (-1,-1), colors.white),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 8),
    ]))
    story.append(rating_table)
    story.append(Spacer(1, 0.15 * inch))

    narrative = (
        f"This assessment evaluated {summary.analytics_processed} analytics across {len(techniques)} ATT&CK techniques. "
        f"The workbook shows {techniques_with_coverage} techniques with at least one matched implementation and an overall coverage of {coverage_pct:.1f}%. "
        f"Scored analytics average {avg_robustness:.2f} robustness and {avg_precision:.2f} precision across {len(scored_scores)} scored files, with {len(unscored_scores)} analytics missing one or both scores."
    )
    story.append(p(narrative, body))
    story.append(Spacer(1, 0.1 * inch))

    story.append(p("Analysis-at-a-Glance", h1))
    story.append(Image(str(dashboard_png), width=7.2*inch, height=4.15*inch))
    story.append(PageBreak())

    story.append(p("Score and Coverage Distributions", h1))
    story.append(Image(str(dist_png), width=7.3*inch, height=2.55*inch))
    story.append(Spacer(1, 0.1 * inch))
    story.append(p("Histogram notes: the implementation coverage chart uses the workbook's `Implementation Coverage Percent` values directly and preserves the `0%` bucket.", body_small))
    story.append(PageBreak())

    story.append(p("Technique Coverage", h1))
    tech_table_data = [[
        p("Technique ID", table_text),
        p("Technique Name", table_text),
        p("Coverage", table_text),
        p("Applicable Analytics", table_text),
        p("Avg Robustness", table_text),
        p("Avg Precision", table_text),
    ]]
    for t in techniques:
        avg_r, avg_p = technique_avgs[t.technique_id]
        cov_cell = f"{t.coverage_percent:.1f}% ({t.coverage_ratio})"
        tech_table_data.append([
            p(t.technique_id, table_text),
            p(t.technique_name, table_text),
            p(cov_cell, table_text),
            p(str(len(t.analytic_files)), center_small),
            p("" if avg_r is None else f"{avg_r:.2f}", center_small),
            p("" if avg_p is None else f"{avg_p:.2f}", center_small),
        ])
    tech_table = LongTable(tech_table_data, repeatRows=1, colWidths=[0.8*inch, 2.5*inch, 1.0*inch, 1.0*inch, 0.95*inch, 0.95*inch])
    tech_style = TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1F2937")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 8.0),
        ("LEADING", (0,0), (-1,-1), 9.0),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#D9D9D9")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("ALIGN", (2,1), (5,-1), "CENTER"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#FAFAFA")]),
    ])
    for idx, t in enumerate(techniques, start=1):
        tech_style.add("BACKGROUND", (2, idx), (2, idx), bucket_color(t.coverage_percent, "coverage"))
        avg_r, avg_p = technique_avgs[t.technique_id]
        tech_style.add("BACKGROUND", (4, idx), (4, idx), bucket_color(avg_r, "quality"))
        tech_style.add("BACKGROUND", (5, idx), (5, idx), bucket_color(avg_p, "quality"))
    tech_table.setStyle(tech_style)
    story.append(tech_table)
    story.append(PageBreak())

    story.append(p("Analytic Scores", h1))
    score_table_data = [[
        p("Analytic File", table_text),
        p("Analytic Title", table_text),
        p("Robustness", table_text),
        p("Precision", table_text),
        p("Implementation Matches", table_text),
    ]]
    for s in scores:
        implementation_matches = sum(1 for t in techniques if s.file in t.analytic_files)
        score_table_data.append([
            p(s.file, table_text),
            p(s.title, table_text),
            p("" if s.robustness is None else f"{s.robustness:.2f}", center_small),
            p("" if s.precision is None else f"{s.precision:.2f}", center_small),
            p(str(implementation_matches), center_small),
        ])
    score_table = LongTable(score_table_data, repeatRows=1, colWidths=[1.9*inch, 2.8*inch, 0.8*inch, 0.8*inch, 1.0*inch])
    score_style = TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1F2937")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 8.0),
        ("LEADING", (0,0), (-1,-1), 9.0),
        ("GRID", (0,0), (-1,-1), 0.25, colors.HexColor("#D9D9D9")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("ALIGN", (2,1), (-1,-1), "CENTER"),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#FAFAFA")]),
    ])
    for idx, s in enumerate(scores, start=1):
        score_style.add("BACKGROUND", (2, idx), (2, idx), bucket_color(s.robustness, "quality"))
        score_style.add("BACKGROUND", (3, idx), (3, idx), bucket_color(s.precision, "quality"))
    score_table.setStyle(score_style)
    story.append(score_table)
    story.append(PageBreak())

    # Observations
    story.append(p("Key Observations", h1))
    top_techniques = sorted(techniques, key=lambda t: (t.coverage_percent, t.matched_count, t.technique_id), reverse=True)[:10]
    low_techniques = sorted(techniques, key=lambda t: (t.coverage_percent, -t.matched_count, t.technique_id))[:10]
    top_robust = sorted([s for s in scores if s.robustness is not None], key=lambda s: (s.robustness or 0, s.precision or 0), reverse=True)[:10]
    top_prec = sorted([s for s in scores if s.precision is not None], key=lambda s: (s.precision or 0, s.robustness or 0), reverse=True)[:10]
    unscored = [s for s in scores if not s.scored][:10]

    def obs_list(title: str, items: Sequence[str]) -> None:
        story.append(p(f"<b>{title}</b>", h2))
        if items:
            bullets = "<br/>".join([f"• {x}" for x in items])
            story.append(p(bullets, body_small))
        else:
            story.append(p("None", body_small))

    obs_list("Highest coverage techniques", [f"{t.technique_id} — {t.technique_name} ({t.coverage_percent:.1f}%, {t.coverage_ratio})" for t in top_techniques])
    obs_list("Lowest coverage techniques", [f"{t.technique_id} — {t.technique_name} ({t.coverage_percent:.1f}%, {t.coverage_ratio})" for t in low_techniques])
    obs_list("Highest robustness analytics", [f"{s.file} — {s.title} ({s.robustness:.2f})" for s in top_robust])
    obs_list("Highest precision analytics", [f"{s.file} — {s.title} ({s.precision:.2f})" for s in top_prec])
    obs_list("Unscored analytics", [f"{s.file} — {s.title} ({s.missing_scores or s.notes or 'unscored'})" for s in unscored])

    story.append(Spacer(1, 0.1 * inch))
    story.append(p("Decision-Maker Takeaways", h1))
    takeaways = [
        f"Prioritize the {sum(1 for t in techniques if t.coverage_percent == 0):d} techniques with 0% coverage before expanding breadth elsewhere.",
        f"Use the {len(unscored)} unscored analytics as the first quality-review queue for robustness and precision scoring.",
        f"Focus enhancement work on analytics below the 1.6 quality threshold to lift average robustness and precision.",
    ]
    story.append(p("<br/>".join([f"• {x}" for x in takeaways]), body))

    if include_navigator and navigator_dir:
        navigator_dir.mkdir(parents=True, exist_ok=True)
        write_navigator_layers(navigator_dir, techniques, technique_avgs)
        story.append(PageBreak())
        story.append(p("Navigator Layers Generated", h1))
        story.append(p("The following ATT&CK Navigator layer files were generated in the output folder:", body))
        story.append(p("<br/>".join(["• implementation_coverage.json", "• average_robustness.json", "• average_precision.json"]), body))

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=portrait(A4),
        leftMargin=0.55 * inch,
        rightMargin=0.55 * inch,
        topMargin=0.5 * inch,
        bottomMargin=0.5 * inch,
        title="ATT&amp;CK Coverage Executive Report",
        author="OpenAI",
    )

    def on_page(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.grey)
        canvas.drawRightString(doc.pagesize[0] - 0.55 * inch, 0.35 * inch, f"Page {doc.page}")
        canvas.drawString(0.55 * inch, 0.35 * inch, "Coverage Report Generator")
        canvas.restoreState()

    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    return output_pdf


def write_navigator_layers(output_dir: Path, techniques: Sequence[TechniqueRow], technique_avgs: Dict[str, Tuple[Optional[float], Optional[float]]]) -> None:
    coverage_layer = make_navigator_layer("Implementation Coverage", techniques, lambda t: t.coverage_percent)
    robustness_layer = make_navigator_layer("Average Robustness", techniques, lambda t: technique_avgs[t.technique_id][0])
    precision_layer = make_navigator_layer("Average Precision", techniques, lambda t: technique_avgs[t.technique_id][1])
    (output_dir / "implementation_coverage.json").write_text(json.dumps(coverage_layer, indent=2), encoding="utf-8")
    (output_dir / "average_robustness.json").write_text(json.dumps(robustness_layer, indent=2), encoding="utf-8")
    (output_dir / "average_precision.json").write_text(json.dumps(precision_layer, indent=2), encoding="utf-8")


def make_navigator_layer(name: str, techniques: Sequence[TechniqueRow], value_fn) -> Dict[str, Any]:
    techniques_json: List[Dict[str, Any]] = []
    for t in techniques:
        value = value_fn(t)
        if value is None:
            continue
        techniques_json.append({
            "techniqueID": t.technique_id,
            "score": round(float(value), 2),
            "comment": t.technique_name,
            "enabled": True,
        })
    return {
        "version": "4.5",
        "name": name,
        "domain": "enterprise-attack",
        "description": f"{name} generated from coverage report workbook",
        "techniques": techniques_json,
        "gradient": {
            "colors": ["#C62828", "#F9A825", "#2E7D32"],
            "minValue": 0,
            "maxValue": 100 if name == "Implementation Coverage" else 4,
        },
        "legendItems": [],
        "metadata": [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate an executive ATT&CK coverage report from a standardized workbook.")
    parser.add_argument("workbook", type=Path, help="Path to the standardized coverage analysis Excel workbook")
    parser.add_argument("--output", type=Path, default=None, help="Output PDF path (default: alongside workbook)")
    parser.add_argument("--navigator-dir", type=Path, default=None, help="Optional output directory for Navigator JSON layers")
    args = parser.parse_args()

    workbook = args.workbook.resolve()
    if not workbook.exists():
        raise SystemExit(f"Workbook not found: {workbook}")

    output = args.output or workbook.with_name(f"{workbook.stem}_coverage_report.pdf")
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    build_pdf(workbook, output, include_navigator=args.navigator_dir is not None, navigator_dir=args.navigator_dir)
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
