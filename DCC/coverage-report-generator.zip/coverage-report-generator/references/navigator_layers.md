# Optional Navigator layers

If Navigator layers are requested, generate three JSON files:
- `implementation_coverage.json`
- `average_robustness.json`
- `average_precision.json`

Each layer should include technique IDs from the workbook and score values derived from the corresponding metric. Use a simple Navigator layer structure that can be imported into ATT&CK Navigator.
