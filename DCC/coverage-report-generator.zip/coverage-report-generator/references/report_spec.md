# Report Specification

This skill operates on a single standardized workbook schema.

## Required worksheets
- `Summary`
- `Technique Coverage`
- `Analytic Scores`

## Summary page metrics
- Analytics evaluated
- Technique IDs covered
- Techniques with coverage
- Implementation matches
- Scored analytics
- Unscored analytics
- Overall average robustness
- Overall average precision
- ATT&CK version

## Chart page
Render three histograms on one page:
1. Robustness distribution
2. Precision distribution
3. Implementation coverage distribution

The implementation coverage histogram must use the `Implementation Coverage Percent` values directly and must include a true `0%` bucket.

## Technique table
Columns:
- Technique ID
- Technique name
- Coverage percent / ratio
- Applicable analytics count
- Average robustness
- Average precision

## Scoring thresholds
- Coverage: green `>= 75%`, yellow `40-74%`, red `< 40%`
- Robustness / precision: green `>= 2.5`, yellow `1.6-2.4`, red `<= 1.5`
