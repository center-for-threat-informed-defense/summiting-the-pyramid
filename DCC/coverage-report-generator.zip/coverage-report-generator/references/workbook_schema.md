# Workbook Schema

## Summary
Key/value table in columns A:B. Common rows used by the generator include:
- `Analytics Processed`
- `Analytic Files`
- `ATT&CK Technique IDs`
- `Covered Implementation Row Count`
- `Technique Coverage Row Count`
- `Analytic Score Row Count`

## Technique Coverage
Expected columns:
1. ATT&CK Technique ID
2. ATT&CK Technique Name
3. Matched Implementation Count
4. Total Implementation Count
5. Implementation Coverage Ratio
6. Implementation Coverage Percent
7. Matched Technique Implementations
8. All Technique Implementations
9. Analytic Files
10. Analytic Titles

## Analytic Scores
Expected columns:
1. Analytic File
2. Analytic Title
3. Detection Condition
4. Robustness Score
5. Precision Score
6. Evaluation Expression
7. Missing Scores
8. Notes
